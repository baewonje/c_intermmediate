#include <stdio.h>

void main(){
		int multiple=0;

		for(multiple=1;multiple<100;multiple++){	
		if(multiple%7==0||multiple%9==0)
		printf("7,9�� ��� %d\n",multiple);

		}
			


}
