#include <stdio.h>

void main(){
	int a=0;
	int total=0;
	do
	{
			total= total+a;
			a= a+2;
	}while(a<=100);
			
			printf("%d\n",total);
		
}
