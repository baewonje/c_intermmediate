#include <stdio.h>

void mstarin(){
	   int star=0;
	   int moon=0;

	while(star<5){
			moon=1;
		while(star>=moon){
	
			printf("0");
 			moon++;
	}
				printf("*");
				star++;
				printf("\n");	
	}
}
